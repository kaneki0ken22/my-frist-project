// ========================================
// 格式大师 - 前端
// 统一 /modify 接口，通过 action 参数区分诊断/执行
// 大模型全程参与：诊断 + 执行
// ========================================

const API_BASE = 'http://127.0.0.1:5000';

const TEMPLATE_DETAILS = {
  paper: {
    name: '论文模板（国内本科/硕士毕业论文通用格式）',
    items: [
      { label: '正文', value: '宋体，小四(12pt)，1.5倍行距，首行缩进2字符，两端对齐' },
      { label: '一级标题', value: '黑体，三号(16pt)，加粗，居中，段前12pt/段后6pt' },
      { label: '二级标题', value: '黑体，四号(14pt)，加粗，左对齐，段前6pt/段后0pt' },
      { label: '三级标题', value: '黑体，小四(12pt)，加粗，左对齐，段前0pt/段后0pt' },
      { label: '图表标题', value: '宋体，五号(10.5pt)，居中，段前6pt/段后6pt' },
      { label: '参考文献', value: '宋体，五号(10.5pt)，1.5倍行距，悬挂缩进2字符' },
    ]
  },
  academic: {
    name: '学术模板（英文期刊 APA/MLA 格式）',
    items: [
      { label: '正文', value: 'Times New Roman，12pt，双倍行距，首行缩进0.5英寸' },
      { label: '一级标题', value: 'Times New Roman，14pt，加粗，左对齐，段前12pt/段后6pt' },
      { label: '二级标题', value: 'Times New Roman，12pt，加粗斜体，左对齐，段前6pt/段后0pt' },
      { label: '三级标题', value: 'Times New Roman，12pt，加粗，左对齐，段前6pt/段后0pt' },
      { label: '图表标题', value: 'Times New Roman，10pt，居中，段前6pt/段后6pt' },
      { label: '参考文献', value: 'Times New Roman，10pt，双倍行距，悬挂缩进0.5英寸' },
    ]
  },
  official: {
    name: '公文模板（GB/T 9704-2012 党政机关公文格式）',
    items: [
      { label: '正文', value: '仿宋_GB2312，三号(16pt)，固定行距28磅，首行缩进2字符' },
      { label: '标题', value: '方正小标宋_GBK，二号(22pt)，居中，固定行距32磅' },
      { label: '一级标题', value: '黑体，三号(16pt)，加粗，左对齐，固定行距28磅' },
      { label: '二级标题', value: '楷体_GB2312，三号(16pt)，加粗，左对齐，固定行距28磅' },
      { label: '发文机关/日期', value: '仿宋_GB2312，三号(16pt)，右对齐' },
      { label: '主题词', value: '仿宋_GB2312，三号(16pt)，左对齐，固定行距28磅' },
    ]
  }
};

const AppState = {
  selectedFile: null,
  activeMode: 'template',
  selectedTemplate: null,
  customInstruction: '',
  diagnoseResult: null,
  resultBlob: null,
  resultFileName: null,
};

const DOM = {};

document.addEventListener('DOMContentLoaded', () => {
  DOM.uploadZone = document.getElementById('uploadZone');
  DOM.fileInput = document.getElementById('fileInput');
  DOM.fileInfoPanel = document.getElementById('fileInfoPanel');
  DOM.fileName = document.getElementById('fileName');
  DOM.fileMeta = document.getElementById('fileMeta');
  DOM.modeCard = document.getElementById('modeCard');
  DOM.actionWrap = document.getElementById('actionWrap');
  DOM.diagnoseBtn = document.getElementById('diagnoseBtn');
  DOM.templateBody = document.getElementById('templateBody');
  DOM.customBody = document.getElementById('customBody');
  DOM.customInstruction = document.getElementById('customInstruction');
  DOM.templateDetail = document.getElementById('templateDetail');
  DOM.detailTitle = document.getElementById('detailTitle');
  DOM.detailGrid = document.getElementById('detailGrid');
  DOM.reportCard = document.getElementById('reportCard');
  DOM.reportModeBadge = document.getElementById('reportModeBadge');
  DOM.reportSummary = document.getElementById('reportSummary');
  DOM.headingsFoundSection = document.getElementById('headingsFoundSection');
  DOM.headingsFoundList = document.getElementById('headingsFoundList');
  DOM.operationsList = document.getElementById('operationsList');
  DOM.statusBar = document.getElementById('statusBar');
  DOM.statusSpinner = document.getElementById('statusSpinner');
  DOM.statusText = document.getElementById('statusText');
  DOM.downloadBtn = document.getElementById('downloadBtn');
  DOM.loadingCover = document.getElementById('loadingCover');
  DOM.loadingText = document.getElementById('loadingText');
  DOM.loadingSub = document.getElementById('loadingSub');
  DOM.quickPanel = document.getElementById('quickPanel');

  initEvents();
});

function initEvents() {
  if (!DOM.uploadZone || !DOM.fileInput) return;

  DOM.uploadZone.addEventListener('dragover', e => { e.preventDefault(); DOM.uploadZone.classList.add('dragover'); });
  DOM.uploadZone.addEventListener('dragleave', e => { e.preventDefault(); DOM.uploadZone.classList.remove('dragover'); });
  DOM.uploadZone.addEventListener('drop', e => {
    e.preventDefault();
    DOM.uploadZone.classList.remove('dragover');
    if (e.dataTransfer.files.length > 0) processFile(e.dataTransfer.files[0]);
  });
  DOM.uploadZone.addEventListener('click', () => DOM.fileInput.click());
  DOM.fileInput.addEventListener('change', e => { if (e.target.files.length > 0) processFile(e.target.files[0]); });

  if (DOM.quickPanel) {
    DOM.quickPanel.addEventListener('click', e => {
      const item = e.target.closest('.quick-item');
      if (item) {
        appendQuickTag(item.dataset.tag);
        DOM.quickPanel.classList.remove('show');
        if (DOM.customInstruction) DOM.customInstruction.focus();
      }
    });
  }

  document.addEventListener('click', e => {
    if (DOM.quickPanel && DOM.quickPanel.classList.contains('show') && !e.target.closest('.quick-commands-wrap')) {
      DOM.quickPanel.classList.remove('show');
    }
  });
}

// ─── 文件 ─────────────────────────────────
function processFile(file) {
  if (!file.name.toLowerCase().endsWith('.docx')) { alert('仅支持 .docx 格式'); return; }
  AppState.selectedFile = file;
  AppState.selectedTemplate = null;
  AppState.customInstruction = '';
  AppState.diagnoseResult = null;
  AppState.resultBlob = null;
  if (DOM.fileName) DOM.fileName.textContent = file.name;
  if (DOM.fileMeta) DOM.fileMeta.textContent = formatFileSize(file.size);
  safeDisplay(DOM.fileInfoPanel, 'block');
  safeDisplay(DOM.modeCard, 'block');
  safeDisplay(DOM.actionWrap, 'block');
  safeDisplay(DOM.reportCard, 'none');
  safeDisplay(DOM.templateDetail, 'none');
  safeDisplay(DOM.statusBar, 'none');
  safeDisplay(DOM.downloadBtn, 'none');
  document.querySelectorAll('.template-btn').forEach(b => b.classList.remove('selected'));
  if (DOM.customInstruction) DOM.customInstruction.value = '';
  if (DOM.quickPanel) DOM.quickPanel.classList.remove('show');
  switchMode('template');
}

function clearFile() {
  AppState.selectedFile = null;
  AppState.selectedTemplate = null;
  AppState.customInstruction = '';
  AppState.diagnoseResult = null;
  AppState.resultBlob = null;
  if (DOM.fileInput) DOM.fileInput.value = '';
  safeDisplay(DOM.fileInfoPanel, 'none');
  safeDisplay(DOM.modeCard, 'none');
  safeDisplay(DOM.actionWrap, 'none');
  safeDisplay(DOM.reportCard, 'none');
  safeDisplay(DOM.templateDetail, 'none');
  safeDisplay(DOM.statusBar, 'none');
  document.querySelectorAll('.template-btn').forEach(b => b.classList.remove('selected'));
  if (DOM.customInstruction) DOM.customInstruction.value = '';
  if (DOM.quickPanel) DOM.quickPanel.classList.remove('show');
}

function formatFileSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

// ─── 模式切换 ─────────────────────────────
function switchMode(mode) {
  AppState.activeMode = mode;
  const rT = document.getElementById('modeRadioTemplate');
  const rC = document.getElementById('modeRadioCustom');
  if (mode === 'template') {
    if (rT) rT.classList.add('active');
    if (rC) rC.classList.remove('active');
    safeDisplay(DOM.templateBody, 'block');
    safeDisplay(DOM.customBody, 'none');
    if (DOM.customInstruction) DOM.customInstruction.value = '';
    AppState.customInstruction = '';
    if (DOM.quickPanel) DOM.quickPanel.classList.remove('show');
  } else {
    if (rC) rC.classList.add('active');
    if (rT) rT.classList.remove('active');
    safeDisplay(DOM.customBody, 'block');
    safeDisplay(DOM.templateBody, 'none');
    AppState.selectedTemplate = null;
    document.querySelectorAll('.template-btn').forEach(b => b.classList.remove('selected'));
    safeDisplay(DOM.templateDetail, 'none');
  }
}

// ─── 模板选择 ─────────────────────────────
function selectTemplate(id) {
  AppState.selectedTemplate = id;
  document.querySelectorAll('.template-btn').forEach(b => b.classList.toggle('selected', b.dataset.template === id));
  const d = TEMPLATE_DETAILS[id];
  if (d) {
    if (DOM.detailTitle) DOM.detailTitle.textContent = d.name;
    if (DOM.detailGrid) DOM.detailGrid.innerHTML = d.items.map(i => `<div class="detail-item"><div class="dl">${i.label}</div><div class="dv">${i.value}</div></div>`).join('');
    safeDisplay(DOM.templateDetail, 'block');
  }
}

// ─── 快捷指令 ─────────────────────────────
function toggleQuickPanel() { if (DOM.quickPanel) DOM.quickPanel.classList.toggle('show'); }

function appendQuickTag(tag) {
  const ta = DOM.customInstruction;
  if (!ta) return;
  const cur = ta.value;
  let sep = '';
  if (cur.length > 0 && !cur.endsWith('\n') && !cur.endsWith(' ')) sep = ' ';
  ta.value = cur + sep + tag;
  AppState.customInstruction = ta.value;
}

// ─── fetch 工具函数（带 60 秒超时）───────
async function fetchWithTimeout(url, options, timeoutMs = 60000) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const resp = await fetch(url, { ...options, signal: controller.signal });
    clearTimeout(timeoutId);
    return resp;
  } catch (err) {
    clearTimeout(timeoutId);
    if (err.name === 'AbortError') {
      throw new Error('请求超时（60秒），请简化指令或检查网络后重试');
    }
    throw err;
  }
}

// ─── 第一阶段：诊断（大模型分析）─────────
async function startDiagnose() {
  if (!AppState.selectedFile) { alert('请先上传 Word 文档'); return; }

  const custom = DOM.customInstruction ? DOM.customInstruction.value.trim() : '';
  if (AppState.activeMode === 'custom' && custom) {
    AppState.customInstruction = custom;
  } else if (AppState.activeMode === 'template' && AppState.selectedTemplate) {
    AppState.customInstruction = '';
  } else {
    alert('请选择模板或输入自定义指令');
    return;
  }

  safeDisplay(DOM.reportCard, 'none');
  safeDisplay(DOM.statusBar, 'none');

  if (AppState.activeMode === 'template') {
    showLoading('AI 正在分析诊断...', '大模型正在识别标题、判断段落类型并生成诊断报告');
  } else {
    showLoading('AI 正在分析诊断...', '大模型正在理解需求并分析文档，最长等待 60 秒');
  }

  try {
    const fd = new FormData();
    fd.append('file', AppState.selectedFile);
    fd.append('action', 'diagnose');
    if (AppState.activeMode === 'custom' && AppState.customInstruction) {
      fd.append('custom', AppState.customInstruction);
    } else if (AppState.selectedTemplate) {
      fd.append('template', AppState.selectedTemplate);
    }

    const resp = await fetchWithTimeout(`${API_BASE}/modify`, { method: 'POST', body: fd }, 60000);

    if (!resp.ok) {
      const e = await resp.json().catch(() => ({ error: `服务器错误 (${resp.status})` }));
      throw new Error(e.error || `服务器错误 (${resp.status})`);
    }

    const data = await resp.json();
    AppState.diagnoseResult = data;
    hideLoading();
    renderDiagnoseReport(data);
  } catch (err) {
    hideLoading();
    alert('诊断失败：' + err.message);
  }
}

function renderDiagnoseReport(data) {
  safeDisplay(DOM.reportCard, 'block');

  const isTemplate = data.mode === 'template';
  if (DOM.reportModeBadge) DOM.reportModeBadge.textContent = isTemplate ? '固定模板模式' : '自定义指令模式';

  const icon = isTemplate ? '&#128203;' : '&#129302;';
  const totalOps = data.total_operations || 0;

  // 检查是否有错误信息
  let errorNote = '';
  if (data.error || data.parse_error) {
    errorNote = '<div style="margin-top:8px;padding:8px 12px;background:#fef2f2;border-radius:8px;font-size:12px;color:#ef4444;">'
      + '⚠ ' + escapeHtml(data.error || '大模型返回异常，请简化指令后重试') + '</div>';
  }

  // 大文档提示
  let largeDocNote = '';
  if (data.large_document) {
    largeDocNote = '<div style="margin-top:8px;padding:8px 12px;background:#fffbeb;border-radius:8px;font-size:12px;color:#92400e;">'
      + '文档较大，分析可能需要较长时间</div>';
  }

  if (DOM.reportSummary) DOM.reportSummary.innerHTML = `
    <span class="summary-icon">${icon}</span>
    <div class="summary-info">
      <div class="summary-title">${escapeHtml(data.summary || 'AI 诊断完成')}</div>
      <div class="summary-desc">${data.template_name ? '模板：' + escapeHtml(data.template_name) + '　|　' : ''}共 ${totalOps} 项修改</div>
      ${errorNote}
      ${largeDocNote}
    </div>
  `;

  // 标题层级（显示识别依据）
  if (data.headings_found && data.headings_found.length > 0) {
    safeDisplay(DOM.headingsFoundSection, 'block');
    if (DOM.headingsFoundList) DOM.headingsFoundList.innerHTML = data.headings_found.map(h => {
      const levelLabels = { 1: '一级标题', 2: '二级标题', 3: '三级标题', 4: '四级标题', 5: '五级标题' };
      const basisNote = h.basis ? `<span class="hc-basis">（依据：${escapeHtml(h.basis)}）</span>` : '';
      return `<div class="heading-chip"><span class="hc-level">H${h.level}</span><span class="hc-label">${levelLabels[h.level] || '标题'}</span><span class="hc-text">${escapeHtml(h.text)}</span>${basisNote}</div>`;
    }).join('');
  } else {
    safeDisplay(DOM.headingsFoundSection, 'none');
  }

  // 操作清单（显示识别依据）
  if (data.operations && data.operations.length > 0) {
    if (DOM.operationsList) DOM.operationsList.innerHTML = data.operations.map(op => {
      const category = op.category || '操作';
      const location = op.location || '';
      const basis = op.basis || '';
      const current = op.current || '';
      const target = op.target || '';
      return `
        <div class="op-row">
          <span class="op-category">${escapeHtml(category)}</span>
          <div class="op-content">
            ${location ? `<div class="op-location">${escapeHtml(location)}</div>` : ''}
            ${basis ? `<div class="op-basis">识别依据：${escapeHtml(basis)}</div>` : ''}
            <div class="op-change">
              ${current ? `<span class="op-current">${escapeHtml(current)}</span>` : ''}
              ${current && target ? `<span class="op-arrow">→</span>` : ''}
              ${target ? `<span class="op-target">${escapeHtml(target)}</span>` : ''}
            </div>
          </div>
        </div>`;
    }).join('');
  } else {
    if (DOM.operationsList) DOM.operationsList.innerHTML = '<div class="ops-empty">未识别到具体操作</div>';
  }

  if (DOM.reportCard) DOM.reportCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ─── 第二阶段：确认并导出（大模型执行）───
async function confirmAndExport() {
  if (!AppState.selectedFile || !AppState.diagnoseResult) { alert('请先完成诊断'); return; }

  const mode = AppState.diagnoseResult.mode;
  showLoading('AI 正在执行修改...', '大模型正在生成修改计划并执行，最长等待 60 秒');
  safeDisplay(DOM.statusBar, 'none');

  try {
    const fd = new FormData();
    fd.append('file', AppState.selectedFile);
    fd.append('action', 'execute');
    if (mode === 'custom' && AppState.customInstruction) {
      fd.append('custom', AppState.customInstruction);
    } else if (AppState.selectedTemplate) {
      fd.append('template', AppState.selectedTemplate);
    }

    const resp = await fetchWithTimeout(`${API_BASE}/modify`, { method: 'POST', body: fd }, 60000);

    if (!resp.ok) {
      const e = await resp.json().catch(() => ({ error: `服务器错误 (${resp.status})` }));
      throw new Error(e.error || `服务器错误 (${resp.status})`);
    }

    const blob = await resp.blob();
    AppState.resultBlob = blob;

    const baseName = AppState.selectedFile.name.replace(/\.docx$/i, '');
    const tn = { paper: '论文', academic: '学术', official: '公文' };
    const tname = tn[AppState.selectedTemplate] || '自定义';
    AppState.resultFileName = `${baseName}_${mode === 'custom' ? '自定义版' : tname + '版'}.docx`;

    hideLoading();
    showStatus('success', '修改完成！所有操作已通过大模型执行');
    safeDisplay(DOM.downloadBtn, 'inline-flex');
    if (DOM.statusBar) DOM.statusBar.scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (err) {
    hideLoading();
    alert('处理失败：' + err.message);
  }
}

function cancelReport() {
  safeDisplay(DOM.reportCard, 'none');
  AppState.diagnoseResult = null;
}

// ─── 下载 ─────────────────────────────────
function downloadFile() {
  if (!AppState.resultBlob) { alert('没有可下载的文件'); return; }
  const url = URL.createObjectURL(AppState.resultBlob);
  const a = document.createElement('a');
  a.href = url;
  a.download = AppState.resultFileName || 'modified.docx';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ─── 状态 / 加载 ──────────────────────────
function showStatus(type, msg) {
  safeDisplay(DOM.statusBar, 'flex');
  safeDisplay(DOM.statusSpinner, type === 'loading' ? 'inline-block' : 'none');
  if (DOM.statusText) DOM.statusText.textContent = msg;
  if (DOM.statusText) DOM.statusText.className = 'status-text' + (type === 'success' ? ' success' : type === 'error' ? ' error' : '');
  if (type !== 'success') safeDisplay(DOM.downloadBtn, 'none');
}

function showLoading(text, sub) {
  if (DOM.loadingText) DOM.loadingText.textContent = text || '正在处理...';
  if (DOM.loadingSub) DOM.loadingSub.textContent = sub || '';
  safeDisplay(DOM.loadingCover, 'flex');
}

function hideLoading() { safeDisplay(DOM.loadingCover, 'none'); }

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// 安全设置 display，避免 null 报错
function safeDisplay(el, value) {
  if (el) el.style.display = value;
}
