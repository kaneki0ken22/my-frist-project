"""
格式大师 - 后端服务
统一 /modify 接口，通过 action 参数区分诊断/执行
大模型全程参与：诊断（判断标题+生成报告）+ 执行（生成修改计划+执行）
"""

import os
import io
import re
import json
import sys
import traceback
import requests
from dotenv import load_dotenv
from flask import Flask, request, send_file, jsonify
from flask_cors import CORS
from docx import Document
from docx.shared import Pt, Cm, Emu, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

load_dotenv(os.path.join(os.path.dirname(os.path.dirname(__file__)), '.env'))

app = Flask(__name__)
CORS(app)

DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")
DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1/chat/completions"

# ═══════════════════════════════════════════════════════════════
# 模板参数定义
# ═══════════════════════════════════════════════════════════════

TEMPLATES = {
    "paper": {
        "name": "论文模板",
        "body": {
            "font_name": "宋体",
            "font_name_east": "宋体",
            "font_size": Pt(12),
            "line_spacing": 1.5,
            "first_line_indent": Cm(0.74),
            "space_before": Pt(0),
            "space_after": Pt(0),
            "alignment": WD_ALIGN_PARAGRAPH.JUSTIFY,
        },
        "heading1": {
            "font_name": "黑体",
            "font_name_east": "黑体",
            "font_size": Pt(16),
            "bold": True,
            "line_spacing": 1.5,
            "alignment": WD_ALIGN_PARAGRAPH.CENTER,
            "space_before": Pt(12),
            "space_after": Pt(6),
            "outline_level": 1,
            "first_line_indent": Pt(0),
        },
        "heading2": {
            "font_name": "黑体",
            "font_name_east": "黑体",
            "font_size": Pt(14),
            "bold": True,
            "line_spacing": 1.5,
            "alignment": WD_ALIGN_PARAGRAPH.LEFT,
            "space_before": Pt(6),
            "space_after": Pt(0),
            "outline_level": 2,
            "first_line_indent": Pt(0),
        },
        "heading3": {
            "font_name": "黑体",
            "font_name_east": "黑体",
            "font_size": Pt(12),
            "bold": True,
            "line_spacing": 1.5,
            "alignment": WD_ALIGN_PARAGRAPH.LEFT,
            "space_before": Pt(0),
            "space_after": Pt(0),
            "outline_level": 3,
            "first_line_indent": Pt(0),
        },
        "figure_caption": {
            "font_name": "宋体",
            "font_name_east": "宋体",
            "font_size": Pt(10.5),
            "line_spacing": 1.5,
            "alignment": WD_ALIGN_PARAGRAPH.CENTER,
            "space_before": Pt(6),
            "space_after": Pt(6),
            "first_line_indent": Pt(0),
        },
        "reference": {
            "font_name": "宋体",
            "font_name_east": "宋体",
            "font_size": Pt(10.5),
            "line_spacing": 1.5,
            "first_line_indent": Cm(-0.74),
            "left_indent": Cm(0.74),
            "hanging_indent": Cm(0.74),
            "alignment": WD_ALIGN_PARAGRAPH.JUSTIFY,
        },
    },
    "academic": {
        "name": "学术模板",
        "body": {
            "font_name": "Times New Roman",
            "font_name_east": "Times New Roman",
            "font_size": Pt(12),
            "line_spacing": 2.0,
            "first_line_indent": Cm(1.27),
            "space_before": Pt(0),
            "space_after": Pt(0),
            "alignment": WD_ALIGN_PARAGRAPH.JUSTIFY,
        },
        "heading1": {
            "font_name": "Times New Roman",
            "font_name_east": "Times New Roman",
            "font_size": Pt(14),
            "bold": True,
            "line_spacing": 2.0,
            "alignment": WD_ALIGN_PARAGRAPH.LEFT,
            "space_before": Pt(12),
            "space_after": Pt(6),
            "outline_level": 1,
            "first_line_indent": Pt(0),
        },
        "heading2": {
            "font_name": "Times New Roman",
            "font_name_east": "Times New Roman",
            "font_size": Pt(12),
            "bold": True,
            "italic": True,
            "line_spacing": 2.0,
            "alignment": WD_ALIGN_PARAGRAPH.LEFT,
            "space_before": Pt(6),
            "space_after": Pt(0),
            "outline_level": 2,
            "first_line_indent": Pt(0),
        },
        "heading3": {
            "font_name": "Times New Roman",
            "font_name_east": "Times New Roman",
            "font_size": Pt(12),
            "bold": True,
            "line_spacing": 2.0,
            "alignment": WD_ALIGN_PARAGRAPH.LEFT,
            "space_before": Pt(6),
            "space_after": Pt(0),
            "outline_level": 3,
            "first_line_indent": Pt(0),
        },
        "figure_caption": {
            "font_name": "Times New Roman",
            "font_name_east": "Times New Roman",
            "font_size": Pt(10),
            "line_spacing": 2.0,
            "alignment": WD_ALIGN_PARAGRAPH.CENTER,
            "space_before": Pt(6),
            "space_after": Pt(6),
            "first_line_indent": Pt(0),
        },
        "reference": {
            "font_name": "Times New Roman",
            "font_name_east": "Times New Roman",
            "font_size": Pt(10),
            "line_spacing": 2.0,
            "first_line_indent": Cm(-1.27),
            "left_indent": Cm(1.27),
            "hanging_indent": Cm(1.27),
            "alignment": WD_ALIGN_PARAGRAPH.JUSTIFY,
        },
    },
    "official": {
        "name": "公文模板",
        "body": {
            "font_name": "仿宋_GB2312",
            "font_name_east": "仿宋_GB2312",
            "font_size": Pt(16),
            "line_spacing_pt": Pt(28),
            "first_line_indent": Cm(0.74),
            "space_before": Pt(0),
            "space_after": Pt(0),
            "alignment": WD_ALIGN_PARAGRAPH.JUSTIFY,
        },
        "title": {
            "font_name": "方正小标宋_GBK",
            "font_name_east": "方正小标宋_GBK",
            "font_size": Pt(22),
            "line_spacing_pt": Pt(32),
            "alignment": WD_ALIGN_PARAGRAPH.CENTER,
            "space_before": Pt(12),
            "space_after": Pt(12),
            "first_line_indent": Pt(0),
        },
        "heading1": {
            "font_name": "黑体",
            "font_name_east": "黑体",
            "font_size": Pt(16),
            "bold": True,
            "line_spacing_pt": Pt(28),
            "alignment": WD_ALIGN_PARAGRAPH.LEFT,
            "space_before": Pt(6),
            "space_after": Pt(0),
            "outline_level": 1,
            "first_line_indent": Pt(0),
        },
        "heading2": {
            "font_name": "楷体_GB2312",
            "font_name_east": "楷体_GB2312",
            "font_size": Pt(16),
            "bold": True,
            "line_spacing_pt": Pt(28),
            "alignment": WD_ALIGN_PARAGRAPH.LEFT,
            "space_before": Pt(6),
            "space_after": Pt(0),
            "outline_level": 2,
            "first_line_indent": Pt(0),
        },
        "issuer_date": {
            "font_name": "仿宋_GB2312",
            "font_name_east": "仿宋_GB2312",
            "font_size": Pt(16),
            "line_spacing_pt": Pt(28),
            "alignment": WD_ALIGN_PARAGRAPH.RIGHT,
            "space_before": Pt(12),
            "space_after": Pt(0),
            "first_line_indent": Pt(0),
        },
        "keywords": {
            "font_name": "仿宋_GB2312",
            "font_name_east": "仿宋_GB2312",
            "font_size": Pt(16),
            "line_spacing_pt": Pt(28),
            "alignment": WD_ALIGN_PARAGRAPH.LEFT,
            "space_before": Pt(0),
            "space_after": Pt(0),
            "first_line_indent": Pt(0),
        },
    },
}


# ═══════════════════════════════════════════════════════════════
# 工具函数
# ═══════════════════════════════════════════════════════════════

def get_heading_level(paragraph):
    """通过原生样式识别标题级别（仅作为辅助信息传给大模型，不做最终判断）"""
    style_name = (paragraph.style.name if paragraph.style else "").lower()

    if "heading 1" in style_name or "heading1" in style_name:
        return 1
    if "heading 2" in style_name or "heading2" in style_name:
        return 2
    if "heading 3" in style_name or "heading3" in style_name:
        return 3
    if "heading 4" in style_name or "heading4" in style_name:
        return 4
    if "heading 5" in style_name or "heading5" in style_name:
        return 5
    if "title" in style_name and "heading" not in style_name:
        return 1

    pPr = paragraph._element.find(qn('w:pPr'))
    if pPr is not None:
        outline = pPr.find(qn('w:outlineLvl'))
        if outline is not None:
            val = outline.get(qn('w:val'))
            if val is not None:
                return int(val) + 1

    return 0


def describe_font(style_cfg):
    """将样式配置转为可读字符串"""
    parts = []
    fn = style_cfg.get("font_name_east", "") or style_cfg.get("font_name", "")
    if fn:
        parts.append(fn)
    fs = style_cfg.get("font_size")
    if fs:
        parts.append(f"{fs.pt:.0f}pt")
    if style_cfg.get("bold"):
        parts.append("加粗")
    if style_cfg.get("italic"):
        parts.append("斜体")
    ls = style_cfg.get("line_spacing")
    if ls:
        parts.append(f"行距{ls}倍")
    lspt = style_cfg.get("line_spacing_pt")
    if lspt:
        parts.append(f"固定行距{lspt.pt:.0f}磅")
    al = style_cfg.get("alignment")
    align_map = {
        WD_ALIGN_PARAGRAPH.CENTER: "居中",
        WD_ALIGN_PARAGRAPH.LEFT: "左对齐",
        WD_ALIGN_PARAGRAPH.RIGHT: "右对齐",
        WD_ALIGN_PARAGRAPH.JUSTIFY: "两端对齐",
    }
    if al in align_map:
        parts.append(align_map[al])
    fi = style_cfg.get("first_line_indent")
    if fi and fi > Pt(0):
        parts.append(f"首行缩进{fi.cm:.1f}cm")
    return "，".join(parts)


def describe_current_paragraph(paragraph):
    """描述段落当前格式"""
    parts = []
    if paragraph.runs:
        run = paragraph.runs[0]
        fn = run.font.name
        if fn:
            parts.append(fn)
        fs = run.font.size
        if fs:
            parts.append(f"{fs.pt:.0f}pt")
        if run.bold:
            parts.append("加粗")
        if run.italic:
            parts.append("斜体")
    pf = paragraph.paragraph_format
    ls = pf.line_spacing
    if ls:
        if ls > 10:
            parts.append(f"固定行距{ls.pt:.0f}磅")
        else:
            parts.append(f"行距{ls}倍")
    al = pf.alignment
    align_map = {WD_ALIGN_PARAGRAPH.CENTER: "居中", WD_ALIGN_PARAGRAPH.LEFT: "左对齐",
                 WD_ALIGN_PARAGRAPH.RIGHT: "右对齐", WD_ALIGN_PARAGRAPH.JUSTIFY: "两端对齐"}
    if al in align_map:
        parts.append(align_map[al])
    return "，".join(parts) if parts else "默认格式"


def template_config_to_text(template_name):
    """将模板配置转为可读文本，供大模型理解"""
    template = TEMPLATES.get(template_name)
    if not template:
        return ""
    lines = [f"模板名称：{template['name']}"]
    type_names = {
        "body": "正文", "heading1": "一级标题", "heading2": "二级标题",
        "heading3": "三级标题", "title": "文档标题", "figure_caption": "图表标题",
        "reference": "参考文献", "issuer_date": "发文机关/日期", "keywords": "主题词"
    }
    for ptype, cfg in template.items():
        if ptype == "name":
            continue
        label = type_names.get(ptype, ptype)
        desc = describe_font(cfg)
        lines.append(f"  {label}：{desc}")
    return "\n".join(lines)


def set_paragraph_format(paragraph, style_cfg):
    """应用段落和字体样式配置到单个段落"""
    pf = paragraph.paragraph_format
    pf.alignment = style_cfg.get("alignment", WD_ALIGN_PARAGRAPH.JUSTIFY)

    if "line_spacing_pt" in style_cfg:
        pf.line_spacing = style_cfg["line_spacing_pt"]
        pPr = paragraph._element.get_or_add_pPr()
        spacing = pPr.find(qn('w:spacing'))
        if spacing is None:
            spacing = OxmlElement('w:spacing')
            pPr.append(spacing)
        spacing.set(qn('w:lineRule'), 'exact')
    elif "line_spacing" in style_cfg:
        pf.line_spacing = style_cfg["line_spacing"]

    pf.space_before = style_cfg.get("space_before", Pt(0))
    pf.space_after = style_cfg.get("space_after", Pt(0))

    if "hanging_indent" in style_cfg:
        pf.first_line_indent = style_cfg["hanging_indent"]
    elif "first_line_indent" in style_cfg:
        pf.first_line_indent = style_cfg["first_line_indent"]
    else:
        pf.first_line_indent = Pt(0)

    if "left_indent" in style_cfg:
        pf.left_indent = style_cfg["left_indent"]

    if "outline_level" in style_cfg:
        pPr = paragraph._element.get_or_add_pPr()
        outline_lvl = pPr.find(qn('w:outlineLvl'))
        if outline_lvl is None:
            outline_lvl = OxmlElement('w:outlineLvl')
            pPr.append(outline_lvl)
        outline_lvl.set(qn('w:val'), str(style_cfg["outline_level"] - 1))

    for run in paragraph.runs:
        set_run_font(run, style_cfg)


def set_run_font(run, style_cfg):
    """设置 run 的字体"""
    run.font.size = style_cfg.get("font_size", Pt(12))
    run.font.name = style_cfg.get("font_name", "宋体")
    run.bold = style_cfg.get("bold", False)
    run.italic = style_cfg.get("italic", False)

    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = OxmlElement('w:rFonts')
        rPr.insert(0, rFonts)
    east = style_cfg.get("font_name_east", style_cfg.get("font_name", "宋体"))
    rFonts.set(qn('w:eastAsia'), east)
    rFonts.set(qn('w:ascii'), style_cfg.get("font_name", "宋体"))
    rFonts.set(qn('w:hAnsi'), style_cfg.get("font_name", "宋体"))


# ═══════════════════════════════════════════════════════════════
# DeepSeek API 调用（带完整异常捕获）
# ═══════════════════════════════════════════════════════════════

def call_deepseek(payload, timeout=25):
    """调用 DeepSeek API，返回 (success, content_or_error)
    
    timeout 默认 25 秒，超时后返回错误信息（不抛异常、不卡死）。
    所有异常都被捕获并返回明确的错误信息。
    """
    if not DEEPSEEK_API_KEY:
        return False, "未配置 DEEPSEEK_API_KEY，请在 .env 文件中设置"

    headers = {
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
        "Content-Type": "application/json",
    }

    try:
        resp = requests.post(DEEPSEEK_BASE_URL, headers=headers, json=payload, timeout=timeout)
        if resp.status_code == 200:
            data = resp.json()
            content = data["choices"][0]["message"]["content"]
            return True, content
        else:
            print(f"[DeepSeek] HTTP {resp.status_code}: {resp.text[:500]}", file=sys.stderr)
            return False, f"API 返回 HTTP {resp.status_code}"
    except requests.exceptions.Timeout:
        print(f"[DeepSeek] 请求超时 (>{timeout}s)", file=sys.stderr)
        return False, f"大模型请求超时（>{timeout}秒），请简化指令后重试"
    except requests.exceptions.ConnectionError as e:
        print(f"[DeepSeek] 连接错误: {e}", file=sys.stderr)
        return False, "无法连接大模型服务，请检查网络或 API 配置"
    except requests.exceptions.RequestException as e:
        print(f"[DeepSeek] 请求异常: {e}", file=sys.stderr)
        return False, f"大模型请求异常: {str(e)}"
    except Exception as e:
        print(f"[DeepSeek] 未知异常: {e}", file=sys.stderr)
        traceback.print_exc()
        return False, f"大模型调用异常: {str(e)}"


def parse_llm_json(content):
    """安全解析大模型返回的 JSON，返回 (parsed_dict, error_msg)"""
    try:
        return json.loads(content), None
    except json.JSONDecodeError:
        pass

    # 尝试提取 ```json ... ``` 块
    m = re.search(r'```(?:json)?\s*\n?(.*?)\n?```', content, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1)), None
        except json.JSONDecodeError:
            pass

    # 尝试提取 { ... } 块
    m = re.search(r'\{.*\}', content, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(0)), None
        except json.JSONDecodeError:
            pass

    # 尝试提取 [ ... ] 块
    m = re.search(r'\[.*\]', content, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(0)), None
        except json.JSONDecodeError:
            pass

    print(f"[Parse] JSON 解析失败，原始内容前 1000 字符:\n{content[:1000]}", file=sys.stderr)
    return None, content


# ═══════════════════════════════════════════════════════════════
# 构建文档预览（供大模型使用）
# ═══════════════════════════════════════════════════════════════

def build_doc_preview(file_bytes, max_paragraphs=50):
    """提取文档段落信息，生成大模型可读的文本预览
    
    至少返回前 30 段，最多 max_paragraphs 段。
    包含：段落索引、原生样式名、标题级别标记、当前格式、文本内容（截断到80字）
    """
    doc = Document(io.BytesIO(file_bytes))
    paragraphs = list(doc.paragraphs)
    total_paras = len(paragraphs)

    preview_lines = []
    limit = min(max_paragraphs, total_paras)

    for idx in range(limit):
        para = paragraphs[idx]
        text = para.text.strip()
        style_name = para.style.name if para.style else "Normal"
        level = get_heading_level(para)

        if not text:
            preview_lines.append(f"P{idx}: [空段落] 样式={style_name}")
            continue

        level_tag = f"[H{level}]" if level > 0 else ""
        current_fmt = describe_current_paragraph(para)
        text_snippet = text[:80] + ("..." if len(text) > 80 else "")
        preview_lines.append(
            f"P{idx}: {level_tag}样式=\"{style_name}\" | 格式={current_fmt} | 内容=\"{text_snippet}\""
        )

    doc_preview = "\n".join(preview_lines)

    # 页面信息
    sections_info = []
    for si, section in enumerate(doc.sections):
        pg_w = section.page_width
        pg_h = section.page_height
        w_cm = pg_w.cm if pg_w else 21.0
        h_cm = pg_h.cm if pg_h else 29.7
        orientation = "横向" if w_cm > h_cm else "纵向"
        mt = section.top_margin
        mb = section.bottom_margin
        ml = section.left_margin
        mr = section.right_margin
        sections_info.append(
            f"第{si+1}节: 纸张{orientation} {w_cm:.1f}×{h_cm:.1f}cm, "
            f"上边距{mt.cm if mt else 2.54:.1f} 下边距{mb.cm if mb else 2.54:.1f} "
            f"左边距{ml.cm if ml else 3.18:.1f} 右边距{mr.cm if mr else 3.18:.1f}cm"
        )

    return doc_preview, total_paras, sections_info, paragraphs, doc


# ═══════════════════════════════════════════════════════════════
# 诊断：大模型分析文档（固定模板模式）
# ═══════════════════════════════════════════════════════════════

def diagnose_template_with_llm(file_bytes, template_name):
    """固定模板模式：调大模型分析文档全文，判断每个段落类型并生成诊断报告
    
    大模型负责：
    1. 判断每个段落类型（一级标题/二级标题/三级标题/正文）
    2. 给出识别依据
    3. 对比模板要求，指出需要修改的内容
    """
    template = TEMPLATES.get(template_name)
    if not template:
        return None, f"不支持的模板: {template_name}"

    doc_preview, total_paras, sections_info, paragraphs, doc = build_doc_preview(file_bytes)
    template_desc = template_config_to_text(template_name)

    system_prompt = (
        "你是一个专业的 Word 文档格式分析助手。你需要分析文档的每个段落，判断类型，"
        "并生成详细的诊断报告。\n\n"
        "━━━ 标题识别规则（严格按以下优先级）━━━\n"
        "1. 样式为 \"Heading 1\" / \"标题 1\" / \"heading 1\" → 一级标题\n"
        "2. 样式为 \"Heading 2\" / \"标题 2\" / \"heading 2\" → 二级标题\n"
        "3. 样式为 \"Heading 3\" / \"标题 3\" / \"heading 3\" → 三级标题\n"
        "4. 样式为 \"Title\" / \"标题\" → 一级标题\n"
        "5. 内容以 \"一、\" \"二、\" \"第一章\" \"第1章\" 等开头 → 一级标题\n"
        "6. 内容以 \"1.\" \"2.\" \"1.1\" \"2.1\" 等数字编号开头 → 二级标题\n"
        "7. 内容以 \"（1）\" \"①\" \"(a)\" 等开头 → 三级标题\n"
        "8. 包含句号、逗号，长度超过30字 → 正文\n"
        "9. 样式优先级 > 编号优先级 > 内容特征\n\n"
        "━━━ 输出要求 ━━━\n"
        "必须输出严格的 JSON 对象，格式如下：\n"
        '{\n'
        '  "summary": "一句话总结（如：共识别 3 个一级标题、5 个二级标题、12 个正文段落，需修改 20 项）",\n'
        '  "headings_found": [\n'
        '    {"level": 1, "text": "标题文本", "index": 段落索引, "basis": "识别依据（如：样式 Heading 1 或 以一、开头）"}\n'
        '  ],\n'
        '  "operations": [\n'
        '    {\n'
        '      "category": "一级标题/二级标题/三级标题/正文/图表标题/参考文献",\n'
        '      "location": "段落0（一级标题）",\n'
        '      "basis": "识别依据",\n'
        '      "current": "当前格式描述",\n'
        '      "target": "模板要求的格式"\n'
        '    }\n'
        '  ],\n'
        '  "total_operations": 操作总数\n'
        '}\n\n'
        "重要：\n"
        "- 必须分析所有段落，不能跳过\n"
        "- 每个 operation 必须包含 basis 字段说明识别依据\n"
        "- 不要输出 JSON 以外的任何内容"
    )

    user_prompt = (
        f"模板标准：\n{template_desc}\n\n"
        f"文档页面信息：\n{sections_info[0] if sections_info else '无'}\n\n"
        f"文档全部段落（共{total_paras}段）：\n{doc_preview}\n\n"
        "请按上述模板标准，分析每个段落的类型并生成诊断报告。"
    )

    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": 0.3,
        "max_tokens": 16000,
    }

    success, result = call_deepseek(payload, timeout=25)

    if not success:
        return _fallback_diagnose(file_bytes, template_name, f"大模型调用失败: {result}"), None

    parsed, raw_content = parse_llm_json(result)

    if parsed is None:
        return _fallback_diagnose(file_bytes, template_name, "大模型返回格式异常"), None

    return {
        "mode": "template",
        "template_name": template["name"],
        "template_id": template_name,
        "summary": parsed.get("summary", "AI 诊断完成"),
        "total_operations": parsed.get("total_operations", len(parsed.get("operations", []))),
        "headings_found": parsed.get("headings_found", []),
        "operations": parsed.get("operations", []),
        "large_document": total_paras > 50,
    }, None


# ═══════════════════════════════════════════════════════════════
# 诊断：大模型分析文档（自定义指令模式）
# ═══════════════════════════════════════════════════════════════

def diagnose_custom_with_llm(file_bytes, custom_instruction):
    """自定义指令模式：调大模型理解需求 + 分析文档 + 生成诊断报告"""
    doc_preview, total_paras, sections_info, paragraphs, doc = build_doc_preview(file_bytes)

    system_prompt = (
        "你是一个专业的 Word 文档格式分析助手。你需要分析文档的每个段落，理解用户的修改需求，"
        "并生成详细的诊断报告。\n\n"
        "━━━ 标题识别规则（严格按以下优先级）━━━\n"
        "1. 样式为 \"Heading 1\" / \"标题 1\" / \"heading 1\" → 一级标题\n"
        "2. 样式为 \"Heading 2\" / \"标题 2\" / \"heading 2\" → 二级标题\n"
        "3. 样式为 \"Heading 3\" / \"标题 3\" / \"heading 3\" → 三级标题\n"
        "4. 样式为 \"Title\" / \"标题\" → 一级标题\n"
        "5. 内容以 \"一、\" \"二、\" \"第一章\" \"第1章\" 等开头 → 一级标题\n"
        "6. 内容以 \"1.\" \"2.\" \"1.1\" \"2.1\" 等数字编号开头 → 二级标题\n"
        "7. 内容以 \"（1）\" \"①\" \"(a)\" 等开头 → 三级标题\n"
        "8. 包含句号、逗号，长度超过30字 → 正文\n"
        "9. 样式优先级 > 编号优先级 > 内容特征\n\n"
        "━━━ 输出要求 ━━━\n"
        "必须输出严格的 JSON 对象，格式如下：\n"
        '{\n'
        '  "summary": "一句话总结（如：共识别 3 个一级标题、5 个二级标题，需修改 20 项）",\n'
        '  "headings_found": [\n'
        '    {"level": 1, "text": "标题文本", "index": 段落索引, "basis": "识别依据"}\n'
        '  ],\n'
        '  "operations": [\n'
        '    {\n'
        '      "category": "一级标题/二级标题/三级标题/正文/页面设置/页眉/页脚...",\n'
        '      "location": "段落0（一级标题）",\n'
        '      "basis": "识别依据",\n'
        '      "current": "当前格式描述",\n'
        '      "target": "修改后的目标状态"\n'
        '    }\n'
        '  ],\n'
        '  "total_operations": 操作总数\n'
        '}\n\n'
        "重要：\n"
        "- 必须分析所有段落，不能跳过\n"
        "- 每个 operation 必须包含 basis 字段说明识别依据\n"
        "- 不要输出 JSON 以外的任何内容"
    )

    user_prompt = (
        f"用户需求：{custom_instruction}\n\n"
        f"文档页面信息：\n{sections_info[0] if sections_info else '无'}\n\n"
        f"文档全部段落（共{total_paras}段）：\n{doc_preview}\n\n"
        "请根据用户需求，分析每个段落的类型并生成诊断报告。"
    )

    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": 0.3,
        "max_tokens": 16000,
    }

    success, result = call_deepseek(payload, timeout=25)

    if not success:
        return _fallback_diagnose(file_bytes, None, f"大模型调用失败: {result}"), None

    parsed, raw_content = parse_llm_json(result)

    if parsed is None:
        return _fallback_diagnose(file_bytes, None, "大模型返回格式异常"), None

    return {
        "mode": "custom",
        "summary": parsed.get("summary", "AI 诊断完成"),
        "total_operations": parsed.get("total_operations", len(parsed.get("operations", []))),
        "headings_found": parsed.get("headings_found", []),
        "operations": parsed.get("operations", []),
        "large_document": total_paras > 50,
    }, None


# ═══════════════════════════════════════════════════════════════
# 降级诊断（大模型失败时使用）
# ═══════════════════════════════════════════════════════════════

def _fallback_diagnose(file_bytes, template_name, error_msg):
    """大模型调用失败时的降级诊断报告（纯代码兜底，保证不报错）"""
    try:
        doc = Document(io.BytesIO(file_bytes))
        paragraphs = list(doc.paragraphs)
    except Exception:
        return {
            "mode": "template" if template_name else "custom",
            "summary": f"诊断失败：{error_msg}",
            "total_operations": 0,
            "headings_found": [],
            "operations": [],
            "large_document": False,
            "error": error_msg,
        }

    total_paras = len(paragraphs)
    operations = []
    headings_found = []

    for idx, para in enumerate(paragraphs):
        text = para.text.strip()
        if not text:
            continue

        level = get_heading_level(para)
        style_name = para.style.name if para.style else "Normal"
        current_desc = describe_current_paragraph(para)

        # 识别依据
        if level > 0:
            basis = f"样式 {style_name}"
            headings_found.append({
                "level": level,
                "text": text[:50] + ("..." if len(text) > 50 else ""),
                "index": idx,
                "basis": basis,
            })

        # 类别标签
        if level == 1:
            category = "一级标题"
        elif level == 2:
            category = "二级标题"
        elif level == 3:
            category = "三级标题"
        elif level > 3:
            category = f"{level}级标题"
        else:
            category = "正文"

        location = f"段落{idx}（{category}）"

        operations.append({
            "category": category,
            "location": location,
            "basis": f"样式 {style_name}" if level > 0 else "无标题样式",
            "current": current_desc,
            "target": "需重新诊断（大模型调用失败）",
            "para_index": idx,
        })

    # 页面设置
    for si, section in enumerate(doc.sections):
        pg_w = section.page_width
        pg_h = section.page_height
        w_cm = pg_w.cm if pg_w else 21.0
        h_cm = pg_h.cm if pg_h else 29.7
        orientation = "横向" if w_cm > h_cm else "纵向"
        mt = section.top_margin
        mb = section.bottom_margin
        ml = section.left_margin
        mr = section.right_margin
        operations.append({
            "category": "页面设置",
            "location": f"第{si+1}节",
            "basis": "文档原始页面设置",
            "current": f"纸张{orientation} {w_cm:.1f}×{h_cm:.1f}cm, 上{mt.cm if mt else 2.54:.1f} 下{mb.cm if mb else 2.54:.1f} 左{ml.cm if ml else 3.18:.1f} 右{mr.cm if mr else 3.18:.1f}cm",
            "target": "保持当前设置",
            "para_index": -1,
        })

    return {
        "mode": "template" if template_name else "custom",
        "template_name": TEMPLATES.get(template_name, {}).get("name", "") if template_name else "",
        "template_id": template_name or "",
        "summary": f"降级诊断：{error_msg}。共 {total_paras} 个段落，识别到 {len(headings_found)} 个标题",
        "total_operations": len(operations),
        "headings_found": headings_found,
        "operations": operations,
        "large_document": total_paras > 50,
        "error": error_msg,
    }


# ═══════════════════════════════════════════════════════════════
# 执行：大模型生成修改计划并执行
# ═══════════════════════════════════════════════════════════════

def execute_with_llm(file_bytes, mode, template_name=None, custom_instruction=None):
    """大模型生成修改计划 + 代码执行修改
    
    适用于固定模板和自定义指令两种模式。
    返回 (modified_bytes, error_msg)
    """
    doc_preview, total_paras, sections_info, paragraphs, doc = build_doc_preview(file_bytes)

    # 构建模式相关的上下文
    if mode == "template" and template_name:
        template_desc = template_config_to_text(template_name)
        mode_instruction = (
            f"请严格按照以下模板标准生成修改计划：\n{template_desc}\n\n"
            "你需要判断每个段落的类型（标题/正文/图表/参考文献），"
            "然后按照模板标准下发对应的修改操作。"
        )
    else:
        mode_instruction = f"用户需求：{custom_instruction}"

    system_prompt = (
        "你是一个 Word 文档格式修改器。根据模板标准或用户需求，分析每个段落并生成精确的操作清单。\n\n"
        "━━━ 标题识别规则（严格按以下优先级）━━━\n"
        "1. 样式为 \"Heading 1\" / \"标题 1\" → 一级标题\n"
        "2. 样式为 \"Heading 2\" / \"标题 2\" → 二级标题\n"
        "3. 样式为 \"Heading 3\" / \"标题 3\" → 三级标题\n"
        "4. 样式为 \"Title\" / \"标题\" → 一级标题\n"
        "5. 内容以 \"一、\" \"二、\" \"第一章\" 等开头 → 一级标题\n"
        "6. 内容以 \"1.\" \"2.\" \"1.1\" 等数字编号开头 → 二级标题\n"
        "7. 内容以 \"（1）\" \"①\" \"(a)\" 等开头 → 三级标题\n"
        "8. 包含句号、逗号，长度超过30字 → 正文\n"
        "9. 样式优先级 > 编号优先级 > 内容特征\n\n"
        "━━━ 支持的操作类型 ━━━\n"
        '1. set_font: {"type":"set_font","para_index":N,"font_name":"字体名","font_size":数字pt,"bold":true/false,"italic":true/false}\n'
        '2. set_paragraph_style: {"type":"set_paragraph_style","para_index":N,"alignment":"left/center/right/justify","line_spacing":倍数,"line_spacing_pt":固定磅数,"first_line_indent_cm":首行缩进cm,"left_indent_cm":左缩进cm,"space_before_pt":段前磅数,"space_after_pt":段后磅数}\n'
        '3. set_page: {"type":"set_page","section_index":0,"width_cm":21,"height_cm":29.7,"orientation":"portrait/landscape","margin_top_cm":2.54,"margin_bottom_cm":2.54,"margin_left_cm":3.18,"margin_right_cm":3.18}\n'
        '4. set_outline_level: {"type":"set_outline_level","para_index":N,"level":1/2/3}\n'
        '5. add_header: {"type":"add_header","text":"页眉内容","section_index":0}\n'
        '6. add_footer: {"type":"add_footer","text":"页脚内容","section_index":0}\n'
        '7. add_page_number: {"type":"add_page_number","position":"bottom_center/bottom_right","section_index":0}\n\n'
        "━━━ 规则 ━━━\n"
        "- para_index=-1 表示应用到所有段落\n"
        "- 标题通过样式名和内容共同判断\n"
        "- 必须对每个需要修改的段落都下发操作\n"
        "- 输出严格 JSON 数组，不要任何其他内容"
    )

    user_prompt = (
        f"{mode_instruction}\n\n"
        f"文档页面信息：\n{sections_info[0] if sections_info else '无'}\n\n"
        f"文档全部段落（共{total_paras}段）：\n{doc_preview}\n\n"
        "请生成修改操作清单。"
    )

    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": 0.3,
        "max_tokens": 16000,
    }

    success, result = call_deepseek(payload, timeout=30)

    if not success:
        return file_bytes, f"大模型调用失败: {result}"

    parsed, raw_content = parse_llm_json(result)

    if parsed is None:
        return file_bytes, "大模型返回格式异常，无法解析修改计划"

    # 提取操作列表
    if isinstance(parsed, dict):
        ops = parsed.get("operations", [])
    elif isinstance(parsed, list):
        ops = parsed
    else:
        return file_bytes, "修改计划格式错误"

    if not ops:
        return file_bytes, "大模型未生成任何修改操作"

    # 执行修改
    try:
        doc = Document(io.BytesIO(file_bytes))
        execute_operations(doc, ops)
        output = io.BytesIO()
        doc.save(output)
        output.seek(0)
        return output.getvalue(), None
    except Exception as e:
        traceback.print_exc()
        return file_bytes, f"执行修改时出错: {str(e)}"


# ═══════════════════════════════════════════════════════════════
# 操作执行器
# ═══════════════════════════════════════════════════════════════

def execute_operations(doc, operations):
    """按照操作清单在原文档上执行修改"""
    for op in operations:
        try:
            op_type = op.get("type", "")

            if op_type == "set_font":
                _execute_set_font(doc, op)
            elif op_type == "set_paragraph_style":
                _execute_set_paragraph_style(doc, op)
            elif op_type == "set_page":
                _execute_set_page(doc, op)
            elif op_type == "set_outline_level":
                _execute_set_outline_level(doc, op)
            elif op_type == "add_header":
                _execute_add_header(doc, op)
            elif op_type == "add_footer":
                _execute_add_footer(doc, op)
            elif op_type == "add_page_number":
                _execute_add_page_number(doc, op)
            # 未知类型跳过
        except Exception as e:
            print(f"[Execute] 操作执行失败: {op} -> {e}", file=sys.stderr)
            continue


def _get_target_paragraphs(doc, para_index):
    if para_index == -1:
        return list(doc.paragraphs)
    elif 0 <= para_index < len(doc.paragraphs):
        return [doc.paragraphs[para_index]]
    return []


def _execute_set_font(doc, op):
    para_index = op.get("para_index", -1)
    font_name = op.get("font_name")
    font_size = op.get("font_size")
    bold = op.get("bold")
    italic = op.get("italic")

    targets = _get_target_paragraphs(doc, para_index)
    for para in targets:
        for run in para.runs:
            if font_name:
                run.font.name = font_name
                rPr = run._element.get_or_add_rPr()
                rFonts = rPr.find(qn('w:rFonts'))
                if rFonts is None:
                    rFonts = OxmlElement('w:rFonts')
                    rPr.insert(0, rFonts)
                rFonts.set(qn('w:eastAsia'), font_name)
                rFonts.set(qn('w:ascii'), font_name)
                rFonts.set(qn('w:hAnsi'), font_name)
            if font_size:
                run.font.size = Pt(font_size)
            if bold is not None:
                run.bold = bold
            if italic is not None:
                run.italic = italic


def _execute_set_paragraph_style(doc, op):
    para_index = op.get("para_index", -1)
    alignment_map = {
        "left": WD_ALIGN_PARAGRAPH.LEFT,
        "center": WD_ALIGN_PARAGRAPH.CENTER,
        "right": WD_ALIGN_PARAGRAPH.RIGHT,
        "justify": WD_ALIGN_PARAGRAPH.JUSTIFY,
    }

    targets = _get_target_paragraphs(doc, para_index)
    for para in targets:
        pf = para.paragraph_format

        if "alignment" in op and op["alignment"] in alignment_map:
            pf.alignment = alignment_map[op["alignment"]]

        if "line_spacing" in op:
            pf.line_spacing = op["line_spacing"]

        if "line_spacing_pt" in op:
            pf.line_spacing = Pt(op["line_spacing_pt"])
            pPr = para._element.get_or_add_pPr()
            spacing = pPr.find(qn('w:spacing'))
            if spacing is None:
                spacing = OxmlElement('w:spacing')
                pPr.append(spacing)
            spacing.set(qn('w:lineRule'), 'exact')

        if "first_line_indent_cm" in op:
            pf.first_line_indent = Cm(op["first_line_indent_cm"])

        if "left_indent_cm" in op:
            pf.left_indent = Cm(op["left_indent_cm"])

        if "space_before_pt" in op:
            pf.space_before = Pt(op["space_before_pt"])

        if "space_after_pt" in op:
            pf.space_after = Pt(op["space_after_pt"])


def _execute_set_outline_level(doc, op):
    para_index = op.get("para_index", -1)
    level = op.get("level", 1)

    targets = _get_target_paragraphs(doc, para_index)
    for para in targets:
        pPr = para._element.get_or_add_pPr()
        outline_lvl = pPr.find(qn('w:outlineLvl'))
        if outline_lvl is None:
            outline_lvl = OxmlElement('w:outlineLvl')
            pPr.append(outline_lvl)
        outline_lvl.set(qn('w:val'), str(level - 1))


def _execute_set_page(doc, op):
    section_index = op.get("section_index", 0)
    if section_index >= len(doc.sections):
        return

    section = doc.sections[section_index]

    if "width_cm" in op:
        section.page_width = Cm(op["width_cm"])
    if "height_cm" in op:
        section.page_height = Cm(op["height_cm"])

    if "orientation" in op:
        if op["orientation"] == "landscape":
            w = section.page_width
            h = section.page_height
            if w < h:
                section.page_width = h
                section.page_height = w
        elif op["orientation"] == "portrait":
            w = section.page_width
            h = section.page_height
            if w > h:
                section.page_width = h
                section.page_height = w

    if "margin_top_cm" in op:
        section.top_margin = Cm(op["margin_top_cm"])
    if "margin_bottom_cm" in op:
        section.bottom_margin = Cm(op["margin_bottom_cm"])
    if "margin_left_cm" in op:
        section.left_margin = Cm(op["margin_left_cm"])
    if "margin_right_cm" in op:
        section.right_margin = Cm(op["margin_right_cm"])


def _execute_add_header(doc, op):
    text = op.get("text", "")
    section_index = op.get("section_index", 0)
    if section_index >= len(doc.sections):
        return
    section = doc.sections[section_index]
    header = section.header
    if header.paragraphs:
        header.paragraphs[0].text = text
    else:
        header.add_paragraph(text)


def _execute_add_footer(doc, op):
    text = op.get("text", "")
    section_index = op.get("section_index", 0)
    if section_index >= len(doc.sections):
        return
    section = doc.sections[section_index]
    footer = section.footer
    if footer.paragraphs:
        footer.paragraphs[0].text = text
    else:
        footer.add_paragraph(text)


def _execute_add_page_number(doc, op):
    position = op.get("position", "bottom_center")
    section_index = op.get("section_index", 0)
    if section_index >= len(doc.sections):
        return
    section = doc.sections[section_index]

    if "bottom" in position:
        footer = section.footer
        para = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
        if "center" in position:
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        elif "right" in position:
            para.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        else:
            para.alignment = WD_ALIGN_PARAGRAPH.LEFT

        run = para.add_run()
        fldChar1 = OxmlElement('w:fldChar')
        fldChar1.set(qn('w:fldCharType'), 'begin')
        run._element.append(fldChar1)

        run2 = para.add_run()
        instrText = OxmlElement('w:instrText')
        instrText.set(qn('xml:space'), 'preserve')
        instrText.text = ' PAGE '
        run2._element.append(instrText)

        run3 = para.add_run()
        fldChar2 = OxmlElement('w:fldChar')
        fldChar2.set(qn('w:fldCharType'), 'end')
        run3._element.append(fldChar2)
    else:
        header = section.header
        para = header.paragraphs[0] if header.paragraphs else header.add_paragraph()
        if "center" in position:
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        elif "right" in position:
            para.alignment = WD_ALIGN_PARAGRAPH.RIGHT

        run = para.add_run()
        fldChar1 = OxmlElement('w:fldChar')
        fldChar1.set(qn('w:fldCharType'), 'begin')
        run._element.append(fldChar1)

        run2 = para.add_run()
        instrText = OxmlElement('w:instrText')
        instrText.set(qn('xml:space'), 'preserve')
        instrText.text = ' PAGE '
        run2._element.append(instrText)

        run3 = para.add_run()
        fldChar2 = OxmlElement('w:fldChar')
        fldChar2.set(qn('w:fldCharType'), 'end')
        run3._element.append(fldChar2)


# ═══════════════════════════════════════════════════════════════
# 路由：统一 /modify 接口
# ═══════════════════════════════════════════════════════════════

@app.route("/modify", methods=["POST"])
def modify_document():
    """统一接口，通过 action 参数区分模式：
    - action=diagnose：大模型分析文档，生成诊断报告（JSON）
    - action=execute：大模型生成修改计划 + 执行修改，返回 .docx 文件
    """
    if "file" not in request.files:
        return jsonify({"error": "未上传文件"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "文件名为空"}), 400
    if not file.filename.lower().endswith(".docx"):
        return jsonify({"error": "仅支持 .docx 格式文件"}), 400

    template_name = request.form.get("template", "").strip()
    custom_instruction = request.form.get("custom", "").strip()
    action = request.form.get("action", "diagnose").strip()

    try:
        file_bytes = file.read()

        # ── 解析模式 ──
        if custom_instruction:
            mode = "custom"
        elif template_name:
            if template_name not in TEMPLATES:
                return jsonify({"error": f"不支持的模板: {template_name}"}), 400
            mode = "template"
        else:
            return jsonify({"error": "请提供模板名或自定义指令"}), 400

        # ── 诊断模式 ──
        if action == "diagnose":
            if mode == "template":
                result, err = diagnose_template_with_llm(file_bytes, template_name)
            else:
                result, err = diagnose_custom_with_llm(file_bytes, custom_instruction)

            if err:
                return jsonify({"error": err}), 500

            return jsonify(result)

        # ── 执行模式 ──
        modified_bytes, error_msg = execute_with_llm(
            file_bytes, mode,
            template_name=template_name if mode == "template" else None,
            custom_instruction=custom_instruction if mode == "custom" else None,
        )

        output = io.BytesIO(modified_bytes)
        output.seek(0)

        template_info = TEMPLATES.get(template_name, {}).get("name", "自定义")
        original_name = file.filename.rsplit(".", 1)[0]
        mode_tag = "自定义版" if mode == "custom" else f"{template_info}版"
        download_name = f"{original_name}_{mode_tag}.docx"

        return send_file(
            output,
            mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            as_attachment=True,
            download_name=download_name,
        )

    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": f"处理文件时出错: {str(e)}"}), 500


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "templates": list(TEMPLATES.keys())})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
