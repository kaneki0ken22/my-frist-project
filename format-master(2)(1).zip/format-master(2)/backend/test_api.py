import os
import requests
from dotenv import load_dotenv

load_dotenv()

api_key = os.getenv("DEEPSEEK_API_KEY")
url = "https://api.deepseek.com/v1/chat/completions"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Content-Type": "application/json"
}

payload = {
    "model": "deepseek-v4-flash",  # 或者 deepseek-v4-pro
    "messages": [{"role": "user", "content": "你好"}],
    "max_tokens": 10
}

try:
    response = requests.post(url, headers=headers, json=payload, timeout=10)
    print("状态码:", response.status_code)
    print("响应内容:", response.text)
except Exception as e:
    print("请求失败:", e)